//
//  NavigationByBindingApp.swift
//  NavigationByBinding
//
//  Created by Munavar PM on 13/01/25.
//

import SwiftUI

@main
struct NavigationByBindingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
